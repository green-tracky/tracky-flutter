import 'package:dio/dio.dart';
import 'package:tracky_flutter/data/model/Friend.dart';

class FriendRepository {
  final Dio dio;
  FriendRepository(this.dio);

  // 1. 친구 태그로 검색
  Future<List<UserProfile>> searchFriendByTag(String tag) async {
    final response = await dio.get(
      '/friends/search',
      queryParameters: {'user-tag': tag},
    );
    print("서버 응답: ${response.data}");
    final resData = response.data['data'];
    if (resData is List) {
      return resData.map((e) => UserProfile.fromJson(e)).toList();
    } else {
      print("data가 List가 아님: $resData (${resData.runtimeType})");
      return [];
    }
  }

  // 2. 친구 요청 (친구ID 기준)
  Future<void> inviteFriend(int userId) async {
    await dio.post('/friends/invite/users/$userId');
  }

  // 3. 친구 상세 조회(프로필)
  Future<UserProfile> fetchFriendProfile(int userId) async {
    final response = await dio.get('/users/$userId');
    return UserProfile.fromJson(response.data['data']);
  }

  // 4. 친구 리스트
  Future<List<Friend>> fetchFriendList() async {
    final response = await dio.get('/friends/list');
    print('친구 목록 서버 응답: ${response.data}');
    final resData = response.data['data'];
    if (resData is List) {
      return resData.map((e) => Friend.fromJson(e)).toList();
    } else {
      print("data가 List가 아님: $resData (${resData.runtimeType})");
      return [];
    }
  }
}
