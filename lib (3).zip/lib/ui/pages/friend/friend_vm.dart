import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:tracky_flutter/data/model/Friend.dart';

/// FriendRepository
class FriendRepository {
  final Dio dio;
  FriendRepository(this.dio);

  // 1. 친구 검색 (userTag)
  Future<List<UserProfile>> searchFriendByTag(String tag) async {
    final response = await dio.get(
      '/friends/search',
      queryParameters: {'user-tag': tag},
    );
    final resData = response.data['data'];
    if (resData is List) {
      return resData.map((e) => UserProfile.fromJson(e)).toList();
    } else {
      return [];
    }
  }

  // 2. 친구 요청(추가) (userId로 요청)
  Future<void> inviteFriend(int userId) async {
    await dio.post('/friends/invite/users/$userId');
  }

  // 3. 친구 리스트 (내 전체 친구)
  Future<List<Friend>> fetchFriendList() async {
    try {
      final response = await dio.get('/friends/list');
      print('친구 목록 서버 응답: ${response.data}');

      final resData = response.data['data'];
      if (resData is List) {
        print('친구 리스트 파싱 성공! ${resData.length}명');
        return resData.map((e) => Friend.fromJson(e)).toList();
      } else {
        print('data가 List가 아님: $resData (${resData.runtimeType})');
        return [];
      }
    } catch (e, st) {
      print('친구 리스트 API 에러: $e\n$st');
      rethrow;
    }
  }
}

/// Provider for Repository

final friendRepositoryProvider = Provider<FriendRepository>(
  (ref) => FriendRepository(Dio()), // Dio에 토큰 주입은 필요시 직접!
);

/// 친구 "검색/추가" StateNotifier & Provider
class SearchFriendNotifier extends StateNotifier<AsyncValue<List<UserProfile>>> {
  final Ref ref;
  SearchFriendNotifier(this.ref) : super(const AsyncValue.data([]));

  // 검색
  Future<void> search(String tag) async {
    if (tag.isEmpty) {
      state = const AsyncValue.data([]);
      return;
    }
    try {
      state = const AsyncValue.loading();
      final repo = ref.read(friendRepositoryProvider);
      final results = await repo.searchFriendByTag(tag);
      state = AsyncValue.data(results);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  // 친구 요청
  Future<void> invite(int userId) async {
    try {
      final repo = ref.read(friendRepositoryProvider);
      await repo.inviteFriend(userId);
    } catch (e) {
      // 오류 핸들링 필요시
    }
  }
}

final searchFriendProvider = StateNotifierProvider<SearchFriendNotifier, AsyncValue<List<UserProfile>>>(
  (ref) => SearchFriendNotifier(ref),
);

/// 친구 "리스트" StateNotifier & Provider
class FriendListNotifier extends StateNotifier<AsyncValue<List<Friend>>> {
  final Ref ref;
  FriendListNotifier(this.ref) : super(const AsyncValue.loading());

  Future<void> fetchFriends() async {
    try {
      final repo = ref.read(friendRepositoryProvider);
      print('친구 목록 불러오기 시작');
      final friends = await repo.fetchFriendList();
      print('받아온 친구 리스트: $friends');
      state = AsyncValue.data(friends);
    } catch (e, st) {
      print('Provider에서 친구 목록 불러오기 실패: $e\n$st');
      state = AsyncValue.error(e, st);
    }
  }
}

final friendListProvider = StateNotifierProvider<FriendListNotifier, AsyncValue<List<Friend>>>(
  (ref) => FriendListNotifier(ref),
);
