import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../friend_vm.dart'; // vm 경로 맞춰줘!
import 'friend_list_tile.dart';

class AddFriendResultList extends ConsumerWidget {
  final String tag;
  const AddFriendResultList({super.key, required this.tag});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final searchState = ref.watch(searchFriendProvider);

    // tag가 바뀔 때마다 검색
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(searchFriendProvider.notifier).search(tag);
    });

    return searchState.when(
      data: (users) {
        if (users.isEmpty) {
          return Text(
            '"$tag" 태그로 검색된 친구 없음',
            style: const TextStyle(color: Colors.black),
          );
        }
        return ListView.builder(
          itemCount: users.length,
          itemBuilder: (context, index) {
            final user = users[index];
            return AddFriendListTile(
              name: user.username,
              email: user.userTag,
              onAdd: () async {
                await ref.read(searchFriendProvider.notifier).invite(user.id);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('${user.username}님에게 친구 요청 보냄!')),
                );
              },
            );
          },
        );
      },
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, st) => Center(child: Text('에러: $e')),
    );
  }
}
