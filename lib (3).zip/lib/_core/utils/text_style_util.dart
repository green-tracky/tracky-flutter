import 'package:flutter/material.dart';

TextStyle styleWithColor(TextStyle baseStyle, Color color) {
  return baseStyle.copyWith(color: color);
}
