class RankUser {
  final int rank;
  final String name;
  final double? distance;

  RankUser({required this.rank, required this.name, this.distance});
}
